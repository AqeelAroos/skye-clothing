"use client";

import { create } from "zustand";

interface UIStore {
  isDarkMode: boolean;
  isMobileMenuOpen: boolean;
  isSearchOpen: boolean;
  toggleDarkMode: () => void;
  toggleMobileMenu: () => void;
  toggleSearch: () => void;
  closeMobileMenu: () => void;
  closeSearch: () => void;
}

export const useUIStore = create<UIStore>((set) => ({
  isDarkMode: false,
  isMobileMenuOpen: false,
  isSearchOpen: false,

  toggleDarkMode: () =>
    set((state) => {
      const next = !state.isDarkMode;
      if (typeof document !== "undefined") {
        document.documentElement.classList.toggle("dark", next);
      }
      return { isDarkMode: next };
    }),

  toggleMobileMenu: () =>
    set((state) => ({ isMobileMenuOpen: !state.isMobileMenuOpen })),

  toggleSearch: () =>
    set((state) => ({ isSearchOpen: !state.isSearchOpen })),

  closeMobileMenu: () => set({ isMobileMenuOpen: false }),
  closeSearch: () => set({ isSearchOpen: false }),
}));
