"use client";

import { useRef, useEffect } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, Truck, Shield, RotateCcw, Star } from "lucide-react";
import { ScrollReveal } from "@/components/animations/ScrollReveal";
import { SplitText } from "@/components/animations/SplitText";
import { ParallaxImage } from "@/components/animations/ParallaxImage";
import { ProductCard } from "@/components/product/ProductCard";

const HeroScene = dynamic(
  () =>
    import("@/components/three/HeroScene").then((mod) => ({
      default: mod.HeroScene,
    })),
  { ssr: false }
);

const featuredProducts = [
  {
    id: "1",
    name: "Oversized Urban Tee",
    slug: "oversized-urban-tee",
    basePrice: 4500,
    salePrice: null,
    images: [
      { url: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop", alt: "Urban Tee", isHover: false },
      { url: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=600&h=800&fit=crop", alt: "Urban Tee Back", isHover: true },
    ],
    category: { name: "T-Shirts" },
  },
  {
    id: "2",
    name: "Minimal Cargo Pants",
    slug: "minimal-cargo-pants",
    basePrice: 8900,
    salePrice: 6900,
    images: [
      { url: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=600&h=800&fit=crop", alt: "Cargo Pants", isHover: false },
      { url: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600&h=800&fit=crop", alt: "Cargo Pants Side", isHover: true },
    ],
    category: { name: "Pants" },
  },
  {
    id: "3",
    name: "Essential Hoodie",
    slug: "essential-hoodie",
    basePrice: 7500,
    salePrice: null,
    images: [
      { url: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&h=800&fit=crop", alt: "Hoodie", isHover: false },
      { url: "https://images.unsplash.com/photo-1578768079470-62f67e10f628?w=600&h=800&fit=crop", alt: "Hoodie Back", isHover: true },
    ],
    category: { name: "Hoodies" },
  },
  {
    id: "4",
    name: "Structured Bomber Jacket",
    slug: "structured-bomber-jacket",
    basePrice: 12500,
    salePrice: 9900,
    images: [
      { url: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&h=800&fit=crop", alt: "Bomber Jacket", isHover: false },
      { url: "https://images.unsplash.com/photo-1548126032-079a0fb0099d?w=600&h=800&fit=crop", alt: "Bomber Jacket Side", isHover: true },
    ],
    category: { name: "Jackets" },
  },
];

const collections = [
  {
    name: "Men's Collection",
    slug: "mens",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=1000&fit=crop",
    description: "Bold. Refined. Unapologetic.",
  },
  {
    name: "Women's Collection",
    slug: "womens",
    image: "https://images.unsplash.com/photo-1487222477857-5dc35d5d89d5?w=800&h=1000&fit=crop",
    description: "Effortless elegance, redefined.",
  },
  {
    name: "New Arrivals",
    slug: "new-arrivals",
    image: "https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=800&h=1000&fit=crop",
    description: "Fresh drops. Limited pieces.",
  },
];

export default function HomePage() {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });

  const heroOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.5], [1, 0.9]);
  const heroY = useTransform(scrollYProgress, [0, 0.5], [0, -100]);

  return (
    <>
      {/* Hero Section */}
      <section ref={heroRef} className="relative h-screen overflow-hidden">
        <HeroScene />

        <motion.div
          style={{ opacity: heroOpacity, scale: heroScale, y: heroY }}
          className="relative z-10 flex h-full items-center justify-center px-4"
        >
          <div className="text-center">
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-xs font-medium uppercase tracking-[0.4em] text-accent"
            >
              By Czin Brothers
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="mt-4 font-display text-6xl font-bold uppercase tracking-[0.2em] md:text-8xl lg:text-9xl"
            >
              <span className="gradient-text">SKYE</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="mt-4 text-sm uppercase tracking-[0.3em] text-gray-500 dark:text-gray-400"
            >
              Elevated Streetwear for the Modern Era
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.1 }}
              className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-center"
            >
              <Link href="/products" className="btn-primary gap-2">
                Shop Collection
                <ArrowRight size={16} />
              </Link>
              <Link href="/collections/new-arrivals" className="btn-secondary">
                New Arrivals
              </Link>
            </motion.div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
            className="h-8 w-5 rounded-full border-2 border-gray-400"
          >
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
              className="mx-auto mt-1 h-2 w-1 rounded-full bg-accent"
            />
          </motion.div>
        </motion.div>
      </section>

      {/* Features Bar */}
      <section className="border-b border-t border-gray-200 dark:border-gray-800">
        <div className="mx-auto grid max-w-7xl grid-cols-2 divide-x divide-gray-200 dark:divide-gray-800 lg:grid-cols-4">
          {[
            { icon: Truck, text: "Free Shipping Over LKR 10,000" },
            { icon: Shield, text: "Secure Payment Gateway" },
            { icon: RotateCcw, text: "14-Day Easy Returns" },
            { icon: Star, text: "Premium Quality Assured" },
          ].map((feature) => (
            <div
              key={feature.text}
              className="flex items-center justify-center gap-3 px-4 py-5"
            >
              <feature.icon size={18} className="flex-shrink-0 text-accent" />
              <span className="text-[11px] uppercase tracking-wider">
                {feature.text}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="mx-auto max-w-7xl px-4 py-20 lg:px-8">
        <div className="mb-12 flex items-end justify-between">
          <div>
            <ScrollReveal>
              <p className="text-xs uppercase tracking-[0.3em] text-accent">
                Curated Selection
              </p>
            </ScrollReveal>
            <SplitText
              text="Featured Pieces"
              as="h2"
              className="mt-2 font-display text-4xl font-bold uppercase tracking-wider lg:text-5xl"
              delay={0.2}
            />
          </div>
          <ScrollReveal delay={0.4}>
            <Link
              href="/products"
              className="group flex items-center gap-2 text-xs uppercase tracking-widest"
            >
              View All
              <ArrowRight
                size={14}
                className="transition-transform group-hover:translate-x-1"
              />
            </Link>
          </ScrollReveal>
        </div>

        <div className="grid grid-cols-2 gap-4 md:grid-cols-4 lg:gap-6">
          {featuredProducts.map((product, index) => (
            <ProductCard key={product.id} product={product} index={index} />
          ))}
        </div>
      </section>

      {/* Collections Grid */}
      <section className="mx-auto max-w-7xl px-4 py-20 lg:px-8">
        <div className="mb-12 text-center">
          <ScrollReveal>
            <p className="text-xs uppercase tracking-[0.3em] text-accent">
              Explore
            </p>
          </ScrollReveal>
          <SplitText
            text="Shop by Collection"
            as="h2"
            className="mt-2 font-display text-4xl font-bold uppercase tracking-wider lg:text-5xl"
            delay={0.2}
          />
        </div>

        <div className="grid gap-4 md:grid-cols-3 lg:gap-6">
          {collections.map((collection, i) => (
            <ScrollReveal key={collection.slug} delay={i * 0.15}>
              <Link
                href={`/collections/${collection.slug}`}
                className="group relative block aspect-[3/4] overflow-hidden"
              >
                <ParallaxImage
                  src={collection.image}
                  alt={collection.name}
                  className="absolute inset-0"
                  speed={0.2}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent transition-all duration-500 group-hover:from-black/80" />
                <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-8">
                  <p className="text-xs uppercase tracking-[0.3em] text-accent">
                    {collection.description}
                  </p>
                  <h3 className="mt-2 font-display text-2xl font-bold uppercase tracking-wider text-white lg:text-3xl">
                    {collection.name}
                  </h3>
                  <div className="mt-4 flex items-center gap-2 text-xs uppercase tracking-widest text-white/80 transition-colors group-hover:text-accent">
                    Explore
                    <ArrowRight
                      size={14}
                      className="transition-transform group-hover:translate-x-1"
                    />
                  </div>
                </div>
              </Link>
            </ScrollReveal>
          ))}
        </div>
      </section>

      {/* Brand Statement */}
      <section className="bg-skye-900 py-24 text-white dark:bg-skye-950">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <ScrollReveal>
            <p className="text-xs uppercase tracking-[0.3em] text-accent">
              Our Philosophy
            </p>
          </ScrollReveal>
          <SplitText
            text="Where urban meets elevated. Every piece is designed to make a statement without saying a word."
            as="p"
            className="mt-6 font-display text-2xl font-light leading-relaxed tracking-wide lg:text-4xl"
            delay={0.3}
          />
          <ScrollReveal delay={0.8}>
            <Link
              href="/about"
              className="mt-10 inline-flex items-center gap-2 text-xs uppercase tracking-widest text-accent transition-colors hover:text-white"
            >
              Our Story
              <ArrowRight size={14} />
            </Link>
          </ScrollReveal>
        </div>
      </section>

      {/* Newsletter */}
      <section className="mx-auto max-w-7xl px-4 py-20 lg:px-8">
        <div className="mx-auto max-w-xl text-center">
          <ScrollReveal>
            <p className="text-xs uppercase tracking-[0.3em] text-accent">
              Stay Connected
            </p>
          </ScrollReveal>
          <SplitText
            text="Join the SKYE Community"
            as="h2"
            className="mt-2 font-display text-3xl font-bold uppercase tracking-wider"
            delay={0.2}
          />
          <ScrollReveal delay={0.4}>
            <p className="mt-4 text-sm text-gray-500">
              Get early access to new drops, exclusive offers, and style
              inspiration delivered to your inbox.
            </p>
            <form className="mt-6 flex gap-0" onSubmit={(e) => e.preventDefault()}>
              <input
                type="email"
                placeholder="Your email address"
                className="input-field flex-1"
              />
              <button type="submit" className="btn-primary">
                Subscribe
              </button>
            </form>
          </ScrollReveal>
        </div>
      </section>
    </>
  );
}
