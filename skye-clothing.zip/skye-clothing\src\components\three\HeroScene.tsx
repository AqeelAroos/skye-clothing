"use client";

import { Suspense, useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import {
  Float,
  Environment,
  MeshDistortMaterial,
  MeshWobbleMaterial,
  Sphere,
  Torus,
  Box,
  Icosahedron,
} from "@react-three/drei";
import * as THREE from "three";

function FloatingGeometry() {
  const groupRef = useRef<THREE.Group>(null);
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.1;
      groupRef.current.rotation.x =
        Math.sin(state.clock.elapsedTime * 0.2) * 0.1;
    }
    if (meshRef.current) {
      meshRef.current.rotation.z = state.clock.elapsedTime * 0.15;
    }
  });

  const particlePositions = useMemo(() => {
    const positions = new Float32Array(200 * 3);
    for (let i = 0; i < 200; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 10;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 10;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 10;
    }
    return positions;
  }, []);

  return (
    <group ref={groupRef}>
      <Float speed={2} rotationIntensity={1} floatIntensity={2}>
        <Icosahedron ref={meshRef} args={[1.5, 1]} position={[0, 0, 0]}>
          <MeshDistortMaterial
            color="#c9a96e"
            roughness={0.2}
            metalness={0.8}
            distort={0.3}
            speed={2}
          />
        </Icosahedron>
      </Float>

      <Float speed={1.5} rotationIntensity={2} floatIntensity={1.5}>
        <Torus args={[2.5, 0.05, 16, 100]} position={[0, 0, 0]}>
          <meshStandardMaterial
            color="#c9a96e"
            roughness={0.3}
            metalness={0.9}
            transparent
            opacity={0.6}
          />
        </Torus>
      </Float>

      <Float speed={1} rotationIntensity={0.5} floatIntensity={1}>
        <Torus
          args={[3.2, 0.03, 16, 100]}
          position={[0, 0, 0]}
          rotation={[Math.PI / 4, 0, 0]}
        >
          <meshStandardMaterial
            color="#ffffff"
            roughness={0.3}
            metalness={0.9}
            transparent
            opacity={0.3}
          />
        </Torus>
      </Float>

      <Float speed={3} rotationIntensity={1} floatIntensity={2}>
        <Sphere args={[0.15, 16, 16]} position={[2, 1.5, 0.5]}>
          <MeshWobbleMaterial
            color="#c9a96e"
            factor={0.6}
            speed={2}
            roughness={0.1}
            metalness={1}
          />
        </Sphere>
      </Float>

      <Float speed={2.5} rotationIntensity={1.5} floatIntensity={1}>
        <Box args={[0.3, 0.3, 0.3]} position={[-2, -1, 1]} rotation={[0.5, 0.5, 0]}>
          <meshStandardMaterial
            color="#c9a96e"
            roughness={0.2}
            metalness={0.9}
            transparent
            opacity={0.7}
          />
        </Box>
      </Float>

      <Float speed={2} rotationIntensity={0.5} floatIntensity={1.5}>
        <Sphere args={[0.1, 16, 16]} position={[-1.5, 2, -0.5]}>
          <meshStandardMaterial
            color="#ffffff"
            roughness={0.1}
            metalness={1}
          />
        </Sphere>
      </Float>

      <points>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={200}
            array={particlePositions}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          size={0.02}
          color="#c9a96e"
          transparent
          opacity={0.6}
          sizeAttenuation
        />
      </points>
    </group>
  );
}

function LoadingFallback() {
  return (
    <mesh>
      <sphereGeometry args={[1, 16, 16]} />
      <meshStandardMaterial color="#c9a96e" wireframe />
    </mesh>
  );
}

export function HeroScene() {
  return (
    <div className="absolute inset-0 z-0">
      <Canvas
        camera={{ position: [0, 0, 6], fov: 50 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true }}
        style={{ background: "transparent" }}
      >
        <Suspense fallback={<LoadingFallback />}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[5, 5, 5]} intensity={1} />
          <pointLight position={[-5, -5, -5]} intensity={0.5} color="#c9a96e" />
          <FloatingGeometry />
          <Environment preset="city" />
        </Suspense>
      </Canvas>
    </div>
  );
}
